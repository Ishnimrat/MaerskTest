﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlazeDemo.TestData
{
    public class BlazeDemoLoginForm
    {
        public string EmailId { get; set; }
        public string Password { get; set; }

    }

    public class BlazeDemoInputForm
    {
        public string departureCity { get; set; }
        public string destinationCity { get; set; }
        public string FlightNumber { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string TimeSpent { get; set; }
        public string Date { get; set; }
    }
}

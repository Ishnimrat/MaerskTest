﻿using OneClickARP.TestData;
using System.Collections.Generic;

namespace BlazeDemo.TestData
{
    public static class BlazeDemoData
    {
        public static BlazeDemoLoginForm GetLoginData(Dictionary<string, string> testData)
        {
            BlazeDemoLoginForm data = new BlazeDemoLoginForm();
            data.EmailId = testData["EmailId"];
            data.Password = testData["Password"];
            return data;
        }

        public static BlazeDemoInputForm GetInputData(Dictionary<string, string> testData)
        {
            BlazeDemoInputForm data = new BlazeDemoInputForm();
            data.departureCity = testData["DepartureCity"];
            data.destinationCity = testData["DestinationCity"];
            data.FlightNumber = testData["FlightNumber"];
            return data;
        }
    }
}

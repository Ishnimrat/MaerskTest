﻿namespace Utility.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using NLog;
    using NPOI.SS.UserModel;
    using NPOI.SS.Util;
    using NPOI.XSSF.UserModel;

    /// <summary>
    /// Excel Read Write.
    /// </summary>
    public static class ExcelHelper
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Excel Reader.
        /// </summary>
        /// <param name="filepath">path of excel.</param>
        /// <param name="testCaseName">test case name.</param>
        /// <returns>row data with key value pair.</returns>
        public static Dictionary<string, string> ExcelReader(string filepath, string testCaseName)
        {
            FileStream fis = new FileStream(filepath, FileMode.Open, FileAccess.Read);
            XSSFWorkbook workBook = new XSSFWorkbook(fis);
            ISheet workSheet = workBook.GetSheetAt(0);

            Dictionary<string, string> myDict = new Dictionary<string, string>();
            int rowCount = workSheet.LastRowNum;
            int colCount = workSheet.GetRow(0).LastCellNum;

            // Get Hearder row for key
            IRow headerRow = workSheet.GetRow(0);
            IRow testDataRow = null;

            // get row which hasexpected data
            for (int row = 1; row <= rowCount; row++)
            {
                if (workSheet.GetRow(row).GetCell(0).ToString().Contains(testCaseName))
                {
                    testDataRow = workSheet.GetRow(row);
                    break;
                }
                else
                {
                    continue;
                }
            }

            // return null if no data found
            if (testDataRow == null)
            {
                return null;
            }

            // Add header row as key , and testdata row as value in dictionary
            else
            {
                for (int cell = 0; cell <= colCount - 1; cell++)
                {
                    if (testDataRow.GetCell(cell) == null)
                    {
                        myDict.Add(headerRow.GetCell(cell).StringCellValue, null);
                    }
                    else
                    {
                        myDict.Add(headerRow.GetCell(cell).StringCellValue, testDataRow.GetCell(cell).ToString());
                    }
                }

                return myDict;
            }
        }

        public static IList<Dictionary<string, string>> ExcelReader(string filepath, int index)
        {
            IList<Dictionary<string, string>> outputStream = new List<Dictionary<string, string>>();

            FileStream fis = new FileStream(filepath, FileMode.Open, FileAccess.Read);
            XSSFWorkbook workBook = new XSSFWorkbook(fis);
            ISheet workSheet = workBook.GetSheetAt(index);

            int rowCount = workSheet.LastRowNum;
            int colCount = workSheet.GetRow(0).LastCellNum;

            IRow headerRow = workSheet.GetRow(0);
            IRow testDataRow = null;

            for (int row = 1; row <= rowCount; row++)
            {
                Dictionary<string, string> currentRow = new Dictionary<string, string>();
                for (int cell = 0; cell <= colCount - 1; cell++)
                {
                    testDataRow = workSheet.GetRow(row);
                    if (testDataRow.GetCell(cell) == null)
                    {
                        currentRow.Add(headerRow.GetCell(cell).StringCellValue, null);
                    }
                    else
                    {
                        currentRow.Add(headerRow.GetCell(cell).StringCellValue, testDataRow.GetCell(cell).ToString());
                    }
                }

                outputStream.Add(currentRow);
            }

            return outputStream;
        }

        public static void ExcelWriter(string filepath, string testCaseName, string columnName, string data)
        {
            FileStream fis = new FileStream(filepath, FileMode.Open, FileAccess.Read);
            XSSFWorkbook workBook = new XSSFWorkbook(fis);

            XSSFSheet workSheet = (XSSFSheet)workBook.GetSheetAt(0);

            Dictionary<string, string> myDict = new Dictionary<string, string>();
            int rowCount = workSheet.LastRowNum;
            int colCount = workSheet.GetRow(0).LastCellNum;

            // Get Hearder row for key
            XSSFRow headerRow = (XSSFRow)workSheet.GetRow(0);
            XSSFRow testDataRow = null;

            // get row which hasexpected data
            for (int row = 1; row <= rowCount; row++)
            {
                if (workSheet.GetRow(row).GetCell(0).ToString().Contains(testCaseName))
                {
                    testDataRow = (XSSFRow)workSheet.GetRow(row);
                    break;
                }
                else
                {
                    continue;
                }
            }

            // return null if no data found
            if (testDataRow == null)
            {
                // do nothing
            }

            // Add header row as key , and testdata row as value in dictionary
            else
            {
                for (int indx = 0; indx < colCount; indx++)
                {
                    if (headerRow.GetCell(indx).StringCellValue.ToLower().Contains(columnName.ToLower()))
                    {
                        testDataRow.CreateCell(indx).SetCellValue(data);
                    }
                }
            }

            FileStream fos = new FileStream(filepath, FileMode.Create, FileAccess.Write);
            workBook.Write(fos);
        }

        public static void PopulateExcel(string filepath, int startRow, int colIndx, List<string> dataStream, object sheetIdxOrName = null)
        {
            FileStream fis = null;
            FileStream fos = null;
            startRow = startRow - 1;
            colIndx = colIndx - 1;
            try
            {
                fis = new FileStream(filepath, FileMode.Open, FileAccess.ReadWrite);
                XSSFWorkbook workBook = new XSSFWorkbook(fis);
                XSSFSheet workSheet = null;

                sheetIdxOrName = (sheetIdxOrName == null) ? 1 : sheetIdxOrName;

                if (sheetIdxOrName.GetType() == typeof(string))
                {
                    workSheet = (XSSFSheet)workBook.GetSheet(sheetIdxOrName.ToString());
                }
                else if (sheetIdxOrName.GetType() == typeof(int))
                {
                    workSheet = (XSSFSheet)workBook.GetSheetAt(int.Parse(sheetIdxOrName.ToString()) - 1);
                }

                XSSFRow headerRow = (XSSFRow)workSheet.GetRow(startRow);

                foreach (string value in dataStream)
                {
                    try
                    {
                        workSheet.GetRow(startRow).CreateCell(colIndx).SetCellValue(value);
                    }
                    catch (NullReferenceException)
                    {
                        workSheet.CreateRow(startRow).CreateCell(colIndx).SetCellValue(value);
                    }

                    startRow++;
                }

                fos = new FileStream(filepath, FileMode.Create, FileAccess.Write);
                workBook.Write(fos);
                workBook.Close();
                fis.Close();
                fos.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                fis.Dispose();
                fos.Dispose();
            }
        }

        public static string GetCellValue(string fileName, string cellReference, object sheetIdxOrName)
        {
            FileStream fis = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            XSSFWorkbook workBook = new XSSFWorkbook(fis);

            ISheet workSheet = null;
            if (sheetIdxOrName.GetType().Equals(typeof(int)))
            {
                workSheet = workBook.GetSheetAt(int.Parse(sheetIdxOrName.ToString()) - 1);
            }
            else if (sheetIdxOrName.GetType().Equals(typeof(string)))
            {
                workSheet = workBook.GetSheet(sheetIdxOrName.ToString());
            }

            CellReference cr = new CellReference(cellReference);
            IRow row = workSheet.GetRow(cr.Row);
            string cellValue = row.GetCell(cr.Col).ToString();
            return cellValue;
        }
    }
}

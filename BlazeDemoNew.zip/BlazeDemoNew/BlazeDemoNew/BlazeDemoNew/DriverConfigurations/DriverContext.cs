﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace OneClickARP.DriverConfigurations
{
    [SuppressMessage("Microsoft.Design", "CA1001:TypesThatOwnDisposableFieldsShouldBeDisposable", Justification = "Driver is disposed on test end")]
    public class DriverContext
    {

        //private IWebDriver driver = new ChromeDriver();

        //public IWebDriver Driver
        //{
        //    get
        //    {
        //        return this.driver;
        //    }
        //}

        //public IWebDriver driver = new ChromeDriver();
        //private DriverContext driverContext;

        //public DriverContext(DriverContext driverContext)
        //{
        //    this.driverContext = driverContext;
        //}

        public string TestTitle { get; set; }
        public string CurrentDirectory { get; set; }

        public static string TestDataFolder
        {
            get
            {
                string path = null;
                path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "TestData");
               
                return path;
            }
        }

        //public IWebDriver Driver
        //{
        //    get
        //    {
        //        return this.driver;
        //    }
        //}
    }

}

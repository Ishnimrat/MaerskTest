﻿using NLog;
using NUnit.Framework;
using OneClickARP.DriverActions;
using OneClickARP.DriverConfigurations;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using static OneClickARP.TestData.Enums;

namespace OneClickARP.Base
{
    public class BasePage
    {
        public static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private readonly string btnLogout = "#BtnLogout .notification-user";

        private readonly string tabHome = "home";
        private readonly string tabBlazeDemo = ".navbar-brand";

        private readonly string tabUserName = "a[role='button']";
        private readonly string tabLogout = "ul[role='menu']  a";
       
        public BasePage(IWebDriver driver)            
        {
            this.driver = driver;
        }

        protected IWebDriver driver { get; set; }

        public void Logout(double timeout = -1)
        {
            double timer = (timeout == -1) ? 10 : timeout;
            By locatorUserName = By.CssSelector(tabUserName);
            By locatorLogout = By.CssSelector(tabLogout);
            if (this.driver.IsElementDisplayed(locatorUserName, timer))
            {
                this.driver.Click(locatorUserName, timer);                
                this.driver.Click(locatorLogout, timer); 
            }
        }  

        public BasePage NavigateTo(Options options)
        {
            By locatorHome = By.LinkText(tabHome);
            By locatorBlazeDemo = By.CssSelector(tabBlazeDemo);
            switch (options)
            {
                case Options.LoginPage:                                       
                    this.driver.Click(locatorHome, 2);
                    Assert.That(driver.GetText(locatorBlazeDemo).ToLower() == "blazedemo");
                    break;

               case Options.HomePage:
                   this.driver.Click(locatorBlazeDemo, 2);
                    Assert.That(driver.GetText(locatorHome).ToLower() == "home");
                    break;
            }

            return this;
        }
    }
}

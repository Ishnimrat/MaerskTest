﻿namespace OneClickARP.Base
{
    using NUnit.Framework;
    using NUnit.Framework.Interfaces;
    using BlazeDemo.;
    using BlazeDemo;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Chrome;
    using OneClickARP.DriverConfigurations;
    using System.IO;

    public class BaseTest
    {

        public IWebDriver driver = new ChromeDriver();

        private readonly string txtEmailId = "input#email";
        private readonly string txtPassword = "input#password";
        private readonly string btnLogin = ".btn.btn-primary";

        [OneTimeSetUp]
        public void BeforeEachClass()
        {
            string testTile = TestContext.CurrentContext.Test.Name;
            string currentDictionary = TestContext.CurrentContext.TestDirectory;
            string url = TestSettings.Default.URL;

            this.driver.Manage().Window.Maximize();
            this.driver.Navigate().GoToUrl(url);
        }

        public string GetTestDataPath(params string[] values)
        {
            string testDataPath = DriverContext.TestDataFolder;
            foreach (string path in values)
            {
                testDataPath = Path.Combine(testDataPath, path);
            }

            return testDataPath;
        }

        public void Login()
        {
            By locatorEmailId = By.CssSelector(this.txtEmailId);
            By locatorPassword = By.CssSelector(this.txtPassword);
            By locatorBtnLogin = By.CssSelector(this.btnLogin);

            this.driver.UpdateText(locatorEmailId, TestSettings.Username, 1);
            this.driver.UpdateText(locatorPassword, TestSettings.Password, 1);
            this.driver.Click(locatorBtnLogin, 5);
        }

    }
}

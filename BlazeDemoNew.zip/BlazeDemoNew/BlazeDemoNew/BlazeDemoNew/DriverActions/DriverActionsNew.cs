﻿namespace OneClickARP.DriverActions
{

    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;
    using System;
    using System.Threading;
    using OneClickARP.Base;
    using System.Collections.Generic;
    using System.Linq;
    using OpenQA.Selenium.Interactions;

    public static class DriverActionsNew
    {

        public static readonly int LongTimeout = 30;
        public static readonly int MediumTimeout = 10;
        public static readonly int ShortTimeout = 5;

        public static void WaitForPageLoad(this IWebDriver driver)
        {
            WaitForPageLoad(driver, ShortTimeout);
        }

        public static void Click(this IWebDriver webDriver, By locator, double timeout = -1)
        {
            double timer = (timeout == -1) ? 20 : timeout;
            WaitUnitilElementClickable(webDriver, locator, timer);
            IWebElement element = webDriver.FindElement(locator);

            if (element.Displayed && element.Enabled)
            {
                try
                {
                    try
                    {
                        element.Click();
                    }
                    catch
                    {
                        ((IJavaScriptExecutor)webDriver).ExecuteScript("arguments[0].click();", element);
                    }
                }
                catch (StaleElementReferenceException)
                {
                    WaitForPageLoad(webDriver, timer);
                    WaitUntilElementIsFound(webDriver, locator, timer);
                    element.Click();
                }
                catch (Exception ex)
                {
                    throw new Exception($"Unable to click on {locator}" + ex.StackTrace);
                }
            }

            WaitForPageLoad(webDriver, timer);
        }
        public static void WaitUntilElementIsFound(this IWebDriver webDriver, By locator, double timeout = -1)
        {
            double timer = (timeout == -1) ? ShortTimeout : timeout;
            var wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(timer));
            try
            {
                wait.IgnoreExceptionTypes(typeof(StaleElementReferenceException));
                // wait.Until(driver => webDriver.FindElement(locator).Displayed == true);
                wait.Until<IWebElement>((driver) =>
                {

                    try
                    {
                        IWebElement element = driver.FindElement(locator);
                        if (element.Displayed)
                        {
                            return element;
                        }
                    }

                    catch (NoSuchElementException) { }
                    catch (StaleElementReferenceException) { }

                    return null;
                });
            }

            catch
            {

            }
    }

       public static bool IsElementClickable(this IWebDriver webDriver, By locator, double timeout)
        {
            double timer = (timeout == -1) ? 10 : timeout;
            try
            {
                var by = locator;
                WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(timer));
                IWebElement element = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(@by));

                if (element != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        public static void WaitUnitilElementClickable(this IWebDriver webDriver, By locator, double timeout = -1)
        {
            double timer = (timeout == -1) ? MediumTimeout : timeout;
            var by = locator;
            WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(timer));

            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(@by));
            }
            catch
            {
                try
                {
                    IJavaScriptExecutor js = (IJavaScriptExecutor)webDriver;
                    js.ExecuteScript("arguments[0].scrollIntoView(true);", webDriver.FindElement(by));
                    wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(@by));
                }
                catch
                {
                }
            }
        }

        private static void WaitForPageLoad(this IWebDriver webDriver, double timeout)
        {
            // Wait for ReadyState complete
            try
            {
                new WebDriverWait(webDriver, TimeSpan.FromSeconds(30)).Until(
                    driver =>
                    {
                        return driver is IJavaScriptExecutor jsExecutor
                               &&
                               (bool)jsExecutor.ExecuteScript(
                                   "return document.readyState").Equals("complete");
                    });
            }
            catch
            {
            }

            var javaScriptExecutor = webDriver as IJavaScriptExecutor;

            // Check if JQuery is present and has finished loading
            bool jQueryResult = (bool)javaScriptExecutor.ExecuteScript("return (typeof jQuery != 'undefined');");

            if (jQueryResult)
            {
                try
                {
                    new WebDriverWait(webDriver, TimeSpan.FromSeconds(timeout)).Until(
                        driver =>
                        {
                            return driver is IJavaScriptExecutor jsExecutor
                            && (bool)jsExecutor.ExecuteScript("return (jQuery.active === 0);");
                        });
                }
                catch
                {
                }
            }
        }

        public static void UpdateText(this IWebDriver webDriver, By locator, string text, double timeout = -1)
        {
            try
            {
                double timer = (timeout == -1) ? 10 : timeout;
                IWebElement txtBox = webDriver.FindElement(locator);
                txtBox.Clear();
                txtBox.SendKeys(text);

                int retry = 0;
                while (retry < 3)
                {
                    if (txtBox.GetAttribute("value") == text)
                    {
                        break;
                    }
                    else
                    {
                        txtBox.Clear();
                        txtBox.SendKeys(text);
                        retry++;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("unable to update text: " + ex.StackTrace);
            }
        }

        public static bool IsElementDisplayed(this IWebDriver webDriver, By locator, double timeout = -1)
        {
            double timer = (timeout == -1) ? 30 : timeout;
            try
            {
                IWebElement element = webDriver.FindElement(locator);
                if (element.Displayed)
                {
                    return true;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        public static void Sleep(this IWebDriver webDriver, double seconds)
        {
            Thread.Sleep(int.Parse(seconds.ToString()) * 1000);
        }

        public static void SelectDropDownValue(this IWebDriver webDriver, By locator, By locatorlist,string value)
        {
            webDriver.Click(locator);
            //webDriver.MouseHover(locatorlist);
            var options = webDriver.FindElements(locatorlist);
            // IList<IWebElement> options = webDriver.FindElements(locatorlist);
            options.Where(p => p.Text.ToLower() == value.ToLower()).First().Click();
        }

        public static void MouseHover(this IWebDriver webDriver, By locator)
        {
            Actions actions = new Actions(webDriver);
            actions.MoveToElement(webDriver.FindElement(locator)).Click().Build().Perform();
        }

        public static void ClickUsingJS(this IWebDriver webDriver, By locator)
        {
            webDriver.FindElement(locator);
            ((IJavaScriptExecutor)webDriver).ExecuteScript("arguments[0].click();", locator);
        }

        public static string GetText(this IWebDriver webDriver, By locator, double timeout = -1)
        {
            double timer = (timeout == -1) ? DriverActionsNew.MediumTimeout : timeout;
            webDriver.WaitUntilElementIsFound(locator, timer);
            return webDriver.FindElement(locator).Text;
        }

        //public static void ClickElementByText(this IWebDriver webDriver, By locator, string textToSearch, double timeout = -1, bool exactSearch = true)
        //{
        //    IList<IWebElement> elements = webDriver.FindElements(locator, timeout);
        //    if (elements.Count > 0)
        //    {
        //        IWebElement elm;
        //        if (exactSearch)
        //        {
        //            elm = elements.Where(e => e.Text.ToLower() == textToSearch.ToLower()).First();
        //        }
        //        else
        //        {
        //            elm = elements.Where(e => e.Text.ToLower().Contains(textToSearch.ToLower())).First();
        //        }

        //        webDriver.Click(elm);
        //    }
        //    else
        //    {
        //        throw new Exception($"Locator {locator.Value} retuned no elements.");
        //    }
        //}
    }
}

﻿using BlazeDemo.TestData;
using OneClickARP.Base;
using OneClickARP.DriverActions;
using OpenQA.Selenium;

namespace OneClickARP.PageClass
{
    public class LoginPage : BasePage
    {
       public IWebDriver driver;

        private readonly string txtEmailId = "input#email";
        private readonly string txtPassword = "input#password";
        private readonly string btnLogin = ".btn.btn-primary";

        private readonly string msgLogin = ".panel-body";
       public LoginPage(IWebDriver driver) : base(driver)
       {
           this.driver = driver;
       }
      
        public void Login(BlazeDemoLoginForm testData)
        {
            By locatorEmailId = By.CssSelector(this.txtEmailId);
            By locatorPassword = By.CssSelector(this.txtPassword);
            By locatorBtnLogin = By.CssSelector(this.btnLogin);

            this.driver.UpdateText(locatorEmailId, testData.EmailId, 1);
            this.driver.UpdateText(locatorPassword, testData.Password, 1);
            this.driver.Click(locatorBtnLogin, 5);
        }

        public string GetLoginMessage()
        {
            By locatorMsgLogin = By.CssSelector(this.msgLogin);
            return this.driver.GetText(locatorMsgLogin);
        }
    }
}

﻿using OneClickARP.Properties;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OneClickARP.DriverConfigurations;
using OneClickARP.Base;
using OneClickARP.DriverActions;
using OneClickARP.TestData;
using System;
using BlazeDemo.TestData;
using System.Collections.Generic;

namespace OneClickARP.PageClass
{
    public class HomePage : BasePage
    {
        public IWebDriver driver;

        private readonly string msgWelcome = "h1";

        private readonly string ddDepartureCity = "form[method='post'] > select[name='fromPort']";
        private readonly string listDepartureCity = "form[method='post'] > select[name='fromPort'] > option";
        private readonly string ddDestinationCity = "form[method='post'] > select[name='toPort']";
        private readonly string listDestinationCity = "form[method='post'] > select[name='toPort'] > option";
        private readonly string btnFindFlights = ".btn.btn-primary";

        private readonly string listFlights = "tr > td:nth-of-type(2)";
        private readonly string btnChooseFlight = "tr:nth-of-type({0}) > td:nth-of-type(1) > .btn.btn-small";

        public HomePage(IWebDriver driver) : base (driver)
        {
            this.driver = driver;
        }

        public string GetWelcomeMessage()
        {
            By locWelcomeMsg = By.XPath(msgWelcome);           
            this.driver.WaitUntilElementIsFound(locWelcomeMsg, DriverActionsNew.MediumTimeout);
            return driver.GetText(locWelcomeMsg);
        }

        public HomePage SelectCities(BlazeDemoInputForm testData)
        {
            By locatorDDDepartureCity = By.CssSelector(ddDepartureCity);
            By locatorListDepartureCity = By.CssSelector(listDepartureCity);

            By locatorDDDestinationCity = By.CssSelector(ddDestinationCity);
            By locatorListDestinationCity = By.CssSelector(listDestinationCity);

            By locatorbtnFindFlights = By.CssSelector(btnFindFlights);

            driver.SelectDropDownValue(locatorDDDepartureCity, locatorListDepartureCity, testData.departureCity);
            driver.SelectDropDownValue(locatorDDDestinationCity, locatorListDestinationCity, testData.destinationCity);
 
            this.driver.Click(locatorbtnFindFlights, 1);           
            return this;
        }

        public HomePage SelectFlights(BlazeDemoInputForm testData)
        {
            By locatorListFlights = By.CssSelector(listFlights);
            IList<IWebElement> allFlights = driver.FindElements(locatorListFlights);

            for (int index = 0; index<allFlights.Count; index++)
            {
                if(testData.FlightNumber.ToString() == allFlights[index].Text.ToString())
                {
                    By locatorBtnChooseFlights = By.CssSelector(string.Format(btnChooseFlight, index));
                    this.driver.Click(locatorBtnChooseFlights, 1);
                    break;
                }
            }
            
            return this;
        }

    }
}

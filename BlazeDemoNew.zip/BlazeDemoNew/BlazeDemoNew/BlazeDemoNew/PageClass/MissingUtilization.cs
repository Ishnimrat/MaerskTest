﻿using OneClickARP.Properties;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OneClickARP.DriverConfigurations;
using OneClickARP.Base;
using OneClickARP.DriverActions;
using OneClickARP.TestData;

namespace OneClickARP.PageClass
{
    public class MissingUtilization : BasePage
    {
        public IWebDriver driver;

        private readonly string btnForgot = "input#btnForget";
        private readonly string btnLeave = "input#btnLeave";

        private readonly string ddTypeOfLeaves = "select#Ddlleaves";
        private readonly string calendarStart = "input#MtxtStart";
        private readonly string calendarEnd = "input#MtxtEnd";

        private readonly string btnSave = "input#btnMsave";
     
        public MissingUtilization(IWebDriver driver) : base(driver)
        {
            this.driver = driver;
        }

        //public MissingUtilization ApplyLeaves(LeaveForm testData)
        //{
        //    By loactorLeave = By.CssSelector(btnLeave);
        //    By loactorType = By.CssSelector(ddTypeOfLeaves);
        //    By loactorStart = By.CssSelector(calendarStart);
        //    By locatorEnd = By.CssSelector(calendarEnd);
        //    By locatorSave = By.CssSelector(btnSave);

        //    // this.driver.SelectDropDownValue(loactorType, testData.Type);
        //    this.driver.UpdateText(loactorStart, testData.StartDate);
        //    this.driver.UpdateText(locatorEnd, testData.EndDate);

        //    this.driver.Click(locatorSave);            
        //    return this;
        //}

        public MissingUtilization ChooseForgot()
        {
            By locatorForgot = By.CssSelector(this.btnForgot);
            this.driver.Click(locatorForgot);
            return this;
        }
    }
}


﻿namespace Explorer.TestSuite
{
    using System;
    using System.Collections;
    using OneClickARP.PageClass;
    using NUnit.Framework;
    using OneClickARP.Base;
    using Utility.Helpers;
    using System.Collections.Generic;
    using OneClickARP.TestData;
    using BlazeDemo.TestData;

    [TestFixture]
    public class TestLogin : BaseTest
    {
        public LoginPage Login => new LoginPage(this.driver);
        public HomePage Home => new HomePage(this.driver);

        [Test] 
        public void Logn()
        {
            this.Login.NavigateTo(Enums.Options.LoginPage);
            string inputFile = this.GetTestDataPath("TestDataBlazeDemo.xlsx");
            IList<Dictionary<string, string>> testData = ExcelHelper.ExcelReader(inputFile, 0);

            foreach (Dictionary<string, string> scenario in testData)
            {
                BlazeDemoLoginForm loginData = BlazeDemoData.GetLoginData(scenario);
                this.Login.Login(loginData);
                Assert.That(this.Login.GetLoginMessage().ToLower() == "You are logged in!".ToLower());
            }
        }
        

        //[OneTimeTearDown]
        //public static void AfterEachTest()
        //{
        //    this.Login.Logout();
        //    Assert.That(Home.GetWelcomeMessage().ToLower() == "Welcome to the Simple Travel Agency!".ToLower());
        //}
    }
}

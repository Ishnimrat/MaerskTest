﻿namespace Explorer.TestSuite
{
    using System;
    using System.Collections;
    using OneClickARP.PageClass;
    using NUnit.Framework;
    using OneClickARP.Base;
    using static OneClickARP.TestData.Enums;
    using OneClickARP.TestData;
    using System.Collections.Generic;
    using Utility.Helpers;
    using BlazeDemo.TestData;

    [TestFixture]
    public class TestHomePage : BaseTest
    {
        public LoginPage Login => new LoginPage(this.driver);
        public HomePage Home => new HomePage(this.driver);
        
        [OneTimeSetUp] 
        public void BeforeEachTest()
        {
            this.Login.Login(loginData);
            string inputFile = this.GetTestDataPath("TestDataBlazeDemo.xlsx");
            IList<Dictionary<string, string>> testData = ExcelHelper.ExcelReader(inputFile, 0);

            foreach (Dictionary<string, string> scenario in testData)
            {
                BlazeDemoLoginForm loginData = BlazeDemoData.GetLoginData(scenario);
                this.Login.Login(loginData);
                this.Home.SelectCities(scenario.)
            }
        }
    }
}
